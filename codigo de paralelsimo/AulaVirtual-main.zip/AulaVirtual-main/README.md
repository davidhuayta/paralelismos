# AulaVirtual
Programa que contiene microservicios como horario, cursos, notas, categorias Paralelismo, Concurrencia y sistemas distribuidos
