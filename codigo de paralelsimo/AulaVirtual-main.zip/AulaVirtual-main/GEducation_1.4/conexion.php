<?php 
$host = "localhost";
$user = "root";
$pw ="123456";
//$db ="reg_users";
$db ="aula_virtual";
 ?>